export type ModuleCode =
  | "CRM"
  | "DEBTS"
  | "PAYMENTS"
  | "REPORTS"
  | "ANALYTICS"
  | "INVENTORY"
  | "PRODUCTS"
  | "WAREHOUSES"
  | "STOCK"
  | "STOCK_MOVEMENT"
  | "QR"
  | "QR_LABELS"
  | "DELIVERY"
  | "DDS"
  | "POS"
  | "SALES"
  | "HR"
  | "KPI"
  | "MOYSKLAD"
  | "ONE_C"
  | "INTEGRATIONS";

export const moduleLabels: Record<ModuleCode, string> = {
  CRM: "CRM",
  DEBTS: "Qarzlar",
  PAYMENTS: "To‘lovlar",
  REPORTS: "Hisobotlar",
  ANALYTICS: "Analytics",
  INVENTORY: "Inventory",
  PRODUCTS: "Products",
  WAREHOUSES: "Omborlar",
  STOCK: "Sklad",
  STOCK_MOVEMENT: "Stock Movement",
  QR: "QR",
  QR_LABELS: "QR Labels",
  DELIVERY: "Delivery",
  DDS: "DDS",
  POS: "POS",
  SALES: "Sales / POS",
  HR: "HR",
  KPI: "KPI",
  MOYSKLAD: "MoySklad",
  ONE_C: "1C",
  INTEGRATIONS: "Integratsiyalar",
};

export const moduleCodes: ModuleCode[] = [
  "CRM",
  "DEBTS",
  "PAYMENTS",
  "REPORTS",
  "ANALYTICS",
  "INVENTORY",
  "PRODUCTS",
  "WAREHOUSES",
  "STOCK",
  "STOCK_MOVEMENT",
  "QR",
  "QR_LABELS",
  "DELIVERY",
  "DDS",
  "POS",
  "SALES",
  "HR",
  "KPI",
  "MOYSKLAD",
  "ONE_C",
  "INTEGRATIONS",
];

export const companyModules = moduleCodes;
export const planModules = companyModules;
export const modules = companyModules;
export const allModules = companyModules;

export const starterModules: ModuleCode[] = ["CRM", "DEBTS", "PAYMENTS", "REPORTS"];
export const businessModules: ModuleCode[] = [
  ...starterModules,
  "ANALYTICS",
  "INVENTORY",
  "PRODUCTS",
  "WAREHOUSES",
  "STOCK",
  "STOCK_MOVEMENT",
  "QR",
  "QR_LABELS",
  "DELIVERY",
  "DDS",
  "POS",
  "SALES",
  "MOYSKLAD",
  "ONE_C",
  "INTEGRATIONS",
];
export const proModules: ModuleCode[] = [...businessModules, "HR", "KPI"];

export function normalizeModule(value: unknown): ModuleCode | null {
  if (!value) return null;
  const code = String(value).trim().toUpperCase().replaceAll("-", "_").replaceAll(" ", "_") as ModuleCode;
  return moduleCodes.includes(code) ? code : null;
}

export function normalizeModules(value: unknown): ModuleCode[] {
  if (!value) return [];

  if (Array.isArray(value)) {
    return value.map(normalizeModule).filter(Boolean) as ModuleCode[];
  }

  if (typeof value === "string") {
    try {
      return normalizeModules(JSON.parse(value));
    } catch {
      return value.split(",").map(normalizeModule).filter(Boolean) as ModuleCode[];
    }
  }

  return [];
}

export function modulesForPlan(plan?: string): ModuleCode[] {
  if (plan === "STARTER") return starterModules;
  if (plan === "BUSINESS") return businessModules;
  if (plan === "PRO") return proModules;
  return companyModules;
}

export function getModulesForPlan(plan?: string): ModuleCode[] {
  return modulesForPlan(plan);
}

export function formatLimit(value: number | string | null | undefined) {
  if (value === null || value === undefined || value === "") return "Cheksiz";
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return "Cheksiz";
  return n.toLocaleString("ru-RU");
}

export function formatUZS(value: number | string | null | undefined) {
  const n = Number(value || 0);
  return `${Number.isFinite(n) ? n.toLocaleString("ru-RU") : "0"} UZS`;
}

export function moduleTitle(code: ModuleCode | string) {
  return moduleLabels[code as ModuleCode] || String(code);
}
