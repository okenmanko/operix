import { SetMetadata } from '@nestjs/common';

export const REQUIRED_MODULES_KEY = 'operix_required_modules';
export type ModuleCode =
  | 'CRM'
  | 'DEBTS'
  | 'PAYMENTS'
  | 'REPORTS'
  | 'INVENTORY'
  | 'QR'
  | 'STOCK_MOVEMENT'
  | 'POS'
  | 'DDS'
  | 'DELIVERY'
  | 'ANALYTICS'
  | 'HR'
  | 'SERVICE_CENTER'
  | 'CALL_CENTER'
  | 'MARKETING'
  | 'API'
  | 'KPI'
  | 'AI_DIRECTOR';

export const RequireModule = (...modules: ModuleCode[]) =>
  SetMetadata(REQUIRED_MODULES_KEY, modules);
