import { SetMetadata } from '@nestjs/common';

export const LIMIT_KEY = 'operix_required_limit';
export type LimitResource = 'clients' | 'users' | 'products' | 'warehouses';

export const CheckLimit = (resource: LimitResource) =>
  SetMetadata(LIMIT_KEY, resource);
