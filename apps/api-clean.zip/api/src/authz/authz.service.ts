import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import type { LimitResource } from './limit.decorator';
import type { ModuleCode } from './module.decorator';

@Injectable()
export class AuthzService {
  constructor(private readonly prisma: PrismaService) {}

  async getCompanyModules(companyId: string): Promise<string[]> {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: {
        enabledModules: true,
        status: true,
        trialEndsAt: true,
      },
    });

    if (!company) return [];
    if (company.status === 'BLOCKED') return [];

    if (
      company.status === 'TRIAL' &&
      company.trialEndsAt &&
      company.trialEndsAt.getTime() < Date.now()
    ) {
      return [];
    }

    return company.enabledModules || [];
  }

  async hasModule(companyId: string, module: string): Promise<boolean> {
    const modules = await this.getCompanyModules(companyId);
    return modules
      .map((m) => String(m).toUpperCase())
      .includes(String(module).toUpperCase());
  }

  async assertModules(companyId: string, modules: ModuleCode[], role?: string) {
    const upperRole = String(role || '').toUpperCase();

    if (upperRole === 'SUPER_ADMIN') return true;
    if (!modules || modules.length === 0) return true;

    const enabledModules = await this.getCompanyModules(companyId);
    const normalized = enabledModules.map((m) => String(m).toUpperCase());

    const ok = modules.some((m) => normalized.includes(String(m).toUpperCase()));

    if (!ok) {
      throw new ForbiddenException('Bu modul tarifda yoqilgan emas');
    }

    return true;
  }

  async hasPermission(params: {
    companyId: string;
    userId: string;
    role?: string;
    module: string;
    action?: string;
  }): Promise<boolean> {
    const role = String(params.role || '').toUpperCase();

    if (role === 'SUPER_ADMIN' || role === 'OWNER') return true;

    const moduleAllowed = await this.hasModule(params.companyId, params.module);
    if (!moduleAllowed) return false;

    const permission = await this.prisma.userPermission.findFirst({
      where: {
        companyId: params.companyId,
        userId: params.userId,
        module: params.module,
      },
    });

    if (!permission) return true;

    const action = String(params.action || 'view').toLowerCase();

    if (action === 'view') return permission.canView || permission.allowed;
    if (action === 'create') return permission.canCreate || permission.allowed;
    if (action === 'update') return permission.canUpdate || permission.allowed;
    if (action === 'delete') return permission.canDelete || permission.allowed;

    return permission.allowed;
  }

  async assertLimit(companyId: string, resource: LimitResource, role?: string) {
    const upperRole = String(role || '').toUpperCase();

    if (upperRole === 'SUPER_ADMIN') return true;

    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: {
        clientLimit: true,
        userLimit: true,
        productLimit: true,
        warehouseLimit: true,
      },
    });

    if (!company) {
      throw new ForbiddenException('Kompaniya topilmadi');
    }

    const limitMap: Record<LimitResource, number | null | undefined> = {
      clients: company.clientLimit,
      users: company.userLimit,
      products: company.productLimit,
      warehouses: company.warehouseLimit,
    };

    const limit = limitMap[resource];

    if (limit === null || limit === undefined || Number(limit) <= 0) return true;

    const countMap: Record<LimitResource, () => Promise<number>> = {
      clients: () => this.prisma.client.count({ where: { companyId } }),
      users: () => this.prisma.user.count({ where: { companyId } }),
      products: () => this.prisma.product.count({ where: { companyId } }),
      warehouses: () => this.prisma.warehouse.count({ where: { companyId } }),
    };

    const current = await countMap[resource]();

    if (current >= Number(limit)) {
      throw new ForbiddenException(`Limit tugagan: ${resource}`);
    }

    return true;
  }
}
