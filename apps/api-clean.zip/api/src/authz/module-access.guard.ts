import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthzService } from './authz.service';
import { REQUIRED_MODULES_KEY, type ModuleCode } from './module.decorator';

@Injectable()
export class ModuleAccessGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly authz: AuthzService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const modules = this.reflector.getAllAndOverride<ModuleCode[]>(REQUIRED_MODULES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]) || [];

    const req = context.switchToHttp().getRequest();
    const user = req.user;

    if (!user) return false;
    await this.authz.assertModules(user.companyId, modules, user.role);
    return true;
  }
}
