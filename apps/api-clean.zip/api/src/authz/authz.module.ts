import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { AuthzService } from './authz.service';

@Module({
  imports: [PrismaModule],
  providers: [AuthzService],
  exports: [AuthzService],
})
export class AuthzModule {}
