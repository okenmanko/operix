import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

function normalizeMoney(value: any) {
  if (value === undefined || value === null || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function makeQrCode(companyId: string) {
  const company = companyId.replace(/[^a-zA-Z0-9]/g, '').slice(-6).toUpperCase();
  const time = Date.now().toString(36).toUpperCase();
  const rnd = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `OPX-${company}-${time}-${rnd}`;
}

@Injectable()
export class InventoryService {
  constructor(private readonly prisma: PrismaService) {}

  async summary(companyId: string) {
    const [products, warehouses, inStock, sold, reserved, returned, writtenOff] = await Promise.all([
      this.prisma.product.count({ where: { companyId, isActive: true } }),
      this.prisma.warehouse.count({ where: { companyId, isActive: true } }),
      this.prisma.stockItem.count({ where: { companyId, status: 'IN_STOCK' } }),
      this.prisma.stockItem.count({ where: { companyId, status: 'SOLD' } }),
      this.prisma.stockItem.count({ where: { companyId, status: 'RESERVED' } }),
      this.prisma.stockItem.count({ where: { companyId, status: 'RETURNED' } }),
      this.prisma.stockItem.count({ where: { companyId, status: 'WRITTEN_OFF' } }),
    ]);

    return { products, warehouses, inStock, sold, reserved, returned, writtenOff };
  }

  async products(companyId: string) {
    const products = await this.prisma.product.findMany({
      where: { companyId },
      orderBy: { createdAt: 'desc' },
      include: { stockItems: true },
    });

    return products.map((product) => ({
      ...product,
      totalQty: product.stockItems.length,
      inStockQty: product.stockItems.filter((i) => i.status === 'IN_STOCK').length,
      soldQty: product.stockItems.filter((i) => i.status === 'SOLD').length,
      reservedQty: product.stockItems.filter((i) => i.status === 'RESERVED').length,
      returnedQty: product.stockItems.filter((i) => i.status === 'RETURNED').length,
      writtenOffQty: product.stockItems.filter((i) => i.status === 'WRITTEN_OFF').length,
    }));
  }

  async productDetail(companyId: string, id: string) {
    const product = await this.prisma.product.findFirst({
      where: { id, companyId },
      include: {
        stockItems: { include: { warehouse: true }, orderBy: { createdAt: 'desc' } },
        stockMovements: {
          include: { warehouse: true, stockItem: true },
          orderBy: { createdAt: 'desc' },
          take: 100,
        },
      },
    });

    if (!product) throw new NotFoundException('Mahsulot topilmadi');

    return {
      ...product,
      totalQty: product.stockItems.length,
      inStockQty: product.stockItems.filter((i) => i.status === 'IN_STOCK').length,
      soldQty: product.stockItems.filter((i) => i.status === 'SOLD').length,
      reservedQty: product.stockItems.filter((i) => i.status === 'RESERVED').length,
    };
  }

  async createProduct(companyId: string, data: any) {
    const name = String(data.name || '').trim();
    if (!name) throw new BadRequestException('Mahsulot nomi kerak');

    return this.prisma.product.create({
      data: {
        companyId,
        name,
        sku: data.sku?.trim() || null,
        barcode: data.barcode?.trim() || null,
        brand: data.brand?.trim() || null,
        model: data.model?.trim() || null,
        category: data.category?.trim() || null,
        description: data.description?.trim() || null,
        costPrice: normalizeMoney(data.costPrice),
        salePrice: normalizeMoney(data.salePrice),
        currency: data.currency || 'UZS',
      },
    });
  }

  async updateProduct(companyId: string, id: string, data: any) {
    await this.ensureProduct(companyId, id);

    return this.prisma.product.update({
      where: { id },
      data: {
        name: data.name !== undefined ? String(data.name || '').trim() : undefined,
        sku: data.sku !== undefined ? data.sku?.trim() || null : undefined,
        barcode: data.barcode !== undefined ? data.barcode?.trim() || null : undefined,
        brand: data.brand !== undefined ? data.brand?.trim() || null : undefined,
        model: data.model !== undefined ? data.model?.trim() || null : undefined,
        category: data.category !== undefined ? data.category?.trim() || null : undefined,
        description: data.description !== undefined ? data.description?.trim() || null : undefined,
        costPrice: data.costPrice !== undefined ? normalizeMoney(data.costPrice) : undefined,
        salePrice: data.salePrice !== undefined ? normalizeMoney(data.salePrice) : undefined,
        currency: data.currency || undefined,
        isActive: data.isActive,
      },
    });
  }

  async deleteProduct(companyId: string, id: string) {
    const product = await this.ensureProduct(companyId, id);
    const stockCount = await this.prisma.stockItem.count({ where: { companyId, productId: id } });

    if (stockCount > 0) {
      return this.prisma.product.update({ where: { id }, data: { isActive: false } });
    }

    await this.prisma.product.delete({ where: { id: product.id } });
    return { ok: true };
  }

  async warehouses(companyId: string) {
    const warehouses = await this.prisma.warehouse.findMany({
      where: { companyId },
      include: { stockItems: true },
      orderBy: { createdAt: 'desc' },
    });

    return warehouses.map((warehouse) => ({
      ...warehouse,
      totalQty: warehouse.stockItems.length,
      inStockQty: warehouse.stockItems.filter((i) => i.status === 'IN_STOCK').length,
    }));
  }

  async createWarehouse(companyId: string, data: any) {
    const name = String(data.name || '').trim();
    if (!name) throw new BadRequestException('Sklad nomi kerak');

    return this.prisma.warehouse.create({
      data: { companyId, name, address: data.address?.trim() || null },
    });
  }

  async updateWarehouse(companyId: string, id: string, data: any) {
    await this.ensureWarehouse(companyId, id);

    return this.prisma.warehouse.update({
      where: { id },
      data: {
        name: data.name !== undefined ? String(data.name || '').trim() : undefined,
        address: data.address !== undefined ? data.address?.trim() || null : undefined,
        isActive: data.isActive,
      },
    });
  }

  async deleteWarehouse(companyId: string, id: string) {
    await this.ensureWarehouse(companyId, id);

    const stockCount = await this.prisma.stockItem.count({
      where: { companyId, warehouseId: id, status: { in: ['IN_STOCK', 'RESERVED'] } },
    });

    if (stockCount > 0) {
      return this.prisma.warehouse.update({ where: { id }, data: { isActive: false } });
    }

    await this.prisma.warehouse.delete({ where: { id } });
    return { ok: true };
  }

  async stockItems(companyId: string, params?: { productId?: string; warehouseId?: string; status?: string }) {
    return this.prisma.stockItem.findMany({
      where: {
        companyId,
        productId: params?.productId || undefined,
        warehouseId: params?.warehouseId || undefined,
        status: params?.status || undefined,
      },
      include: { product: true, warehouse: true },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });
  }

  async receiveStock(companyId: string, data: any) {
    const productId = data.productId;
    const warehouseId = data.warehouseId;
    const quantity = Number(data.quantity || 1);

    if (!productId || !warehouseId) throw new BadRequestException('productId va warehouseId kerak');
    if (!Number.isFinite(quantity) || quantity < 1 || quantity > 500) {
      throw new BadRequestException('quantity 1 dan 500 gacha bo‘lishi kerak');
    }

    await this.ensureProduct(companyId, productId);
    await this.ensureWarehouse(companyId, warehouseId);

    const items: any[] = [];

    for (let i = 0; i < quantity; i += 1) {
      const item = await this.prisma.stockItem.create({
        data: {
          companyId,
          productId,
          warehouseId,
          qrCode: makeQrCode(companyId),
          serialNumber: Array.isArray(data.serialNumbers) ? data.serialNumbers[i] || null : null,
          costPrice: normalizeMoney(data.costPrice),
          salePrice: normalizeMoney(data.salePrice),
          currency: data.currency || 'UZS',
          comment: data.comment?.trim() || null,
        },
      });

      await this.prisma.stockMovement.create({
        data: {
          companyId,
          productId,
          stockItemId: item.id,
          warehouseId,
          type: 'IN',
          quantity: 1,
          reason: 'Kirim',
          comment: data.comment?.trim() || null,
        },
      });

      items.push(item);
    }

    return { count: items.length, items };
  }

  async scan(companyId: string, data: { qrCode: string; action: string; comment?: string }) {
    const qrCode = String(data.qrCode || '').trim();
    const action = data.action || 'OUT';

    if (!qrCode) throw new BadRequestException('QR kod kerak');

    const item = await this.prisma.stockItem.findFirst({
      where: { companyId, qrCode },
      include: { product: true, warehouse: true },
    });

    if (!item) throw new NotFoundException('QR topilmadi');

    let nextStatus = item.status;
    let movementType = action;

    if (action === 'OUT' || action === 'SOLD') {
      if (!['IN_STOCK', 'RESERVED', 'RETURNED'].includes(item.status)) {
        throw new BadRequestException(`Bu tovar chiqim qilinmaydi. Status: ${item.status}`);
      }
      nextStatus = 'SOLD';
      movementType = 'OUT';
    }

    if (action === 'RESERVE') {
      if (item.status !== 'IN_STOCK') throw new BadRequestException('Faqat IN_STOCK rezerv qilinadi');
      nextStatus = 'RESERVED';
      movementType = 'RESERVE';
    }

    if (action === 'CANCEL_RESERVE') {
      if (item.status !== 'RESERVED') throw new BadRequestException('Faqat RESERVED cancel qilinadi');
      nextStatus = 'IN_STOCK';
      movementType = 'CANCEL_RESERVE';
    }

    if (action === 'RETURN') {
      nextStatus = 'RETURNED';
      movementType = 'RETURN';
    }

    if (action === 'WRITE_OFF') {
      nextStatus = 'WRITTEN_OFF';
      movementType = 'WRITE_OFF';
    }

    const updated = await this.prisma.stockItem.update({
      where: { id: item.id },
      data: { status: nextStatus, comment: data.comment || item.comment },
      include: { product: true, warehouse: true },
    });

    await this.prisma.stockMovement.create({
      data: {
        companyId,
        productId: item.productId,
        stockItemId: item.id,
        warehouseId: item.warehouseId,
        type: movementType,
        quantity: 1,
        reason: action,
        comment: data.comment || null,
      },
    });

    return updated;
  }

  async movements(companyId: string) {
    return this.prisma.stockMovement.findMany({
      where: { companyId },
      include: { product: true, stockItem: true, warehouse: true },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });
  }

  async qrPrint(companyId: string, productId: string) {
    await this.ensureProduct(companyId, productId);

    const items = await this.prisma.stockItem.findMany({
      where: { companyId, productId },
      include: { product: true, warehouse: true },
      orderBy: { createdAt: 'desc' },
    });

    return items.map((item) => ({
      id: item.id,
      qrCode: item.qrCode,
      productName: item.product.name,
      warehouseName: item.warehouse.name,
      status: item.status,
      serialNumber: item.serialNumber,
    }));
  }

  private async ensureProduct(companyId: string, id: string) {
    const item = await this.prisma.product.findFirst({ where: { companyId, id } });
    if (!item) throw new NotFoundException('Mahsulot topilmadi');
    return item;
  }

  private async ensureWarehouse(companyId: string, id: string) {
    const item = await this.prisma.warehouse.findFirst({ where: { companyId, id } });
    if (!item) throw new NotFoundException('Sklad topilmadi');
    return item;
  }
}
