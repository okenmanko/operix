import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { CurrentUser } from '../auth/current-user.decorator';
import type { AuthUser } from '../auth/current-user.decorator';
import { InventoryService } from './inventory.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RequireModule } from '../authz/module.decorator';
import { ModuleAccessGuard } from '../authz/module-access.guard';
import { CheckLimit } from '../authz/limit.decorator';
import { LimitGuard } from '../authz/limit.guard';

@UseGuards(JwtAuthGuard, ModuleAccessGuard)
@RequireModule('INVENTORY')
@Controller('inventory')
export class InventoryController {
  constructor(private readonly service: InventoryService) {}

  @Get('summary')
  summary(@CurrentUser() user: AuthUser) {
    return this.service.summary(user.companyId);
  }

  @Get('products')
  products(@CurrentUser() user: AuthUser) {
    return this.service.products(user.companyId);
  }

  @Get('products/:id')
  productDetail(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.service.productDetail(user.companyId, id);
  }

  @Post('products')
  @CheckLimit('products')
  @UseGuards(LimitGuard)
  createProduct(@CurrentUser() user: AuthUser, @Body() body: any) {
    return this.service.createProduct(user.companyId, body);
  }

  @Patch('products/:id')
  updateProduct(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() body: any) {
    return this.service.updateProduct(user.companyId, id, body);
  }

  @Delete('products/:id')
  deleteProduct(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.service.deleteProduct(user.companyId, id);
  }

  @Get('warehouses')
  warehouses(@CurrentUser() user: AuthUser) {
    return this.service.warehouses(user.companyId);
  }

  @Post('warehouses')
  @CheckLimit('warehouses')
  @UseGuards(LimitGuard)
  createWarehouse(@CurrentUser() user: AuthUser, @Body() body: any) {
    return this.service.createWarehouse(user.companyId, body);
  }

  @Patch('warehouses/:id')
  updateWarehouse(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() body: any) {
    return this.service.updateWarehouse(user.companyId, id, body);
  }

  @Delete('warehouses/:id')
  deleteWarehouse(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.service.deleteWarehouse(user.companyId, id);
  }

  @Get('items')
  @RequireModule('QR')
  stockItems(
    @CurrentUser() user: AuthUser,
    @Query('productId') productId?: string,
    @Query('warehouseId') warehouseId?: string,
    @Query('status') status?: string,
  ) {
    return this.service.stockItems(user.companyId, { productId, warehouseId, status });
  }

  @Post('receive')
  @RequireModule('QR', 'STOCK_MOVEMENT')
  receiveStock(@CurrentUser() user: AuthUser, @Body() body: any) {
    return this.service.receiveStock(user.companyId, body);
  }

  @Post('scan')
  @RequireModule('QR')
  scan(@CurrentUser() user: AuthUser, @Body() body: any) {
    return this.service.scan(user.companyId, body);
  }

  @Get('movements')
  @RequireModule('STOCK_MOVEMENT')
  movements(@CurrentUser() user: AuthUser) {
    return this.service.movements(user.companyId);
  }

  @Get('qr-print/:productId')
  @RequireModule('QR')
  qrPrint(@CurrentUser() user: AuthUser, @Param('productId') productId: string) {
    return this.service.qrPrint(user.companyId, productId);
  }
}
