import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

type IntegrationProvider = 'TELEGRAM' | 'MOYSKLAD' | 'ONE_C';

type SaveIntegrationDto = {
  provider?: string;
  type?: string;
  isActive?: boolean;
  baseUrl?: string;
  token?: string;
  login?: string;
  password?: string;
  payload?: unknown;
  botCompanyCode?: string;
  telegramDeliveryGroupId?: string;
  telegramReportGroupId?: string;
  moyskladApiUrl?: string;
  moyskladToken?: string;
  oneCApiUrl?: string;
  oneCToken?: string;
  [key: string]: unknown;
};

@Injectable()
export class IntegrationsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings(companyId: string) {
    const settings = await this.prisma.integrationSetting.findMany({
      where: { companyId },
      orderBy: [{ provider: 'asc' }, { key: 'asc' }],
    });

    const byProvider: Record<string, Record<string, string | null>> = {};

    for (const item of settings) {
      if (!byProvider[item.provider]) byProvider[item.provider] = {};
      byProvider[item.provider][item.key] = item.value;
    }

    return {
      botCompanyCode: byProvider.TELEGRAM?.botCompanyCode || '',
      telegramDeliveryGroupId:
        byProvider.TELEGRAM?.telegramDeliveryGroupId || '',
      telegramReportGroupId: byProvider.TELEGRAM?.telegramReportGroupId || '',
      moyskladApiUrl: byProvider.MOYSKLAD?.baseUrl || '',
      moyskladToken: byProvider.MOYSKLAD?.token || '',
      oneCApiUrl: byProvider.ONE_C?.baseUrl || '',
      oneCToken: byProvider.ONE_C?.token || '',
      providers: byProvider,
      raw: settings,
    };
  }

  async saveSettings(companyId: string, data: SaveIntegrationDto) {
    const provider = this.normalizeProvider(data.provider || data.type);

    if (provider) {
      await this.saveProviderSettings(companyId, provider, {
        baseUrl: this.toStringOrNull(data.baseUrl),
        token: this.toStringOrNull(data.token),
        login: this.toStringOrNull(data.login),
        password: this.toStringOrNull(data.password),
        payload:
          data.payload === undefined ? null : JSON.stringify(data.payload ?? null),
      });
    }

    await this.saveProviderSettings(companyId, 'TELEGRAM', {
      botCompanyCode: this.toStringOrNull(data.botCompanyCode),
      telegramDeliveryGroupId: this.toStringOrNull(data.telegramDeliveryGroupId),
      telegramReportGroupId: this.toStringOrNull(data.telegramReportGroupId),
    });

    await this.saveProviderSettings(companyId, 'MOYSKLAD', {
      baseUrl: this.toStringOrNull(data.moyskladApiUrl),
      token: this.toStringOrNull(data.moyskladToken),
    });

    await this.saveProviderSettings(companyId, 'ONE_C', {
      baseUrl: this.toStringOrNull(data.oneCApiUrl),
      token: this.toStringOrNull(data.oneCToken),
    });

    await this.log(
      companyId,
      provider || 'SYSTEM',
      'SAVE_SETTINGS',
      'OK',
      'Integration sozlamalari saqlandi',
      data,
    );

    return this.getSettings(companyId);
  }

  async testMoysklad(companyId: string) {
    return this.testProvider(companyId, 'MOYSKLAD', 'MoySklad');
  }

  async testOneC(companyId: string) {
    return this.testProvider(companyId, 'ONE_C', '1C');
  }

  private async testProvider(
    companyId: string,
    provider: IntegrationProvider,
    title: string,
  ) {
    const settings = await this.getProviderMap(companyId, provider);
    const ok = Boolean(settings.baseUrl && settings.token);

    await this.log(
      companyId,
      provider,
      'TEST',
      ok ? 'OK' : 'MISSING_CONFIG',
      ok ? `${title} config bor` : `${title} URL/token kiritilmagan`,
      { hasBaseUrl: Boolean(settings.baseUrl), hasToken: Boolean(settings.token) },
    );

    return {
      ok,
      message: ok ? `${title} config bor` : `${title} URL/token kiritilmagan`,
    };
  }

  private async getProviderMap(companyId: string, provider: IntegrationProvider) {
    const rows = await this.prisma.integrationSetting.findMany({
      where: { companyId, provider, isActive: true },
    });

    return rows.reduce<Record<string, string>>((acc, row) => {
      acc[row.key] = row.value || '';
      return acc;
    }, {});
  }

  private async saveProviderSettings(
    companyId: string,
    provider: IntegrationProvider,
    values: Record<string, string | null | undefined>,
  ) {
    for (const [key, value] of Object.entries(values)) {
      if (value === undefined) continue;

      const existing = await this.prisma.integrationSetting.findFirst({
        where: { companyId, provider, key },
      });

      if (existing) {
        await this.prisma.integrationSetting.update({
          where: { id: existing.id },
          data: {
            value,
            isActive: true,
          },
        });
      } else {
        await this.prisma.integrationSetting.create({
          data: {
            companyId,
            provider,
            key,
            value,
            isActive: true,
          },
        });
      }
    }
  }

  private async log(
    companyId: string,
    provider: string,
    action: string,
    status: string,
    message?: string,
    payload?: unknown,
  ) {
    await this.prisma.integrationLog.create({
      data: {
        companyId,
        provider,
        action,
        status,
        message,
        payload: payload === undefined ? undefined : (payload as any),
      },
    });
  }

  private normalizeProvider(value?: string): IntegrationProvider | null {
    const normalized = String(value || '')
      .trim()
      .toUpperCase()
      .replace('1C', 'ONE_C')
      .replace('ONEC', 'ONE_C');

    if (normalized === 'TELEGRAM') return 'TELEGRAM';
    if (normalized === 'MOYSKLAD') return 'MOYSKLAD';
    if (normalized === 'ONE_C') return 'ONE_C';
    return null;
  }

  private toStringOrNull(value: unknown) {
    if (value === undefined) return undefined;
    if (value === null) return null;
    return String(value);
  }
}
