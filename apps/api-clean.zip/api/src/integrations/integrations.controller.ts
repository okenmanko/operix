import { Body, Controller, Get, Patch, UseGuards } from '@nestjs/common';
import { CurrentUser } from '../auth/current-user.decorator';
import type { AuthUser } from '../auth/current-user.decorator';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { IntegrationsService } from './integrations.service';

@UseGuards(JwtAuthGuard)
@Controller('integrations')
export class IntegrationsController {
  constructor(private readonly service: IntegrationsService) {}

  @Get()
  get(@CurrentUser() user: AuthUser) {
    return this.service.getSettings(user.companyId);
  }

  @Patch()
  update(@CurrentUser() user: AuthUser, @Body() body: any) {
    return this.service.saveSettings(user.companyId, body || {});
  }

  @Patch('test-moysklad')
  testMoysklad(@CurrentUser() user: AuthUser) {
    return this.service.testMoysklad(user.companyId);
  }

  @Patch('test-1c')
  testOneC(@CurrentUser() user: AuthUser) {
    return this.service.testOneC(user.companyId);
  }
}
