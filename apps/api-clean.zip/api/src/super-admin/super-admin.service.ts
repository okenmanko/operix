import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import type { AuthUser } from '../auth/current-user.decorator';

const MODULES = [
  { code: 'CRM', name: 'CRM', description: 'Mijozlar bazasi' },
  { code: 'DEBTS', name: 'Qarzlar', description: 'USD/UZS qarzdorlik nazorati' },
  { code: 'PAYMENTS', name: 'To‘lovlar', description: 'Qarzga to‘lov kiritish' },
  { code: 'REPORTS', name: 'Hisobotlar', description: 'Qarz, to‘lov, qoldiq va kechikkanlar' },
  { code: 'INVENTORY', name: 'Inventory/Sklad', description: 'Mahsulotlar va omborlar' },
  { code: 'QR', name: 'QR Tovarlar', description: 'Dona-dona QR hisob' },
  { code: 'STOCK_MOVEMENT', name: 'Stock Movement', description: 'Kirim, chiqim, transfer, sotuv' },
  { code: 'POS', name: 'POS/Sales', description: 'QR skan qilib sotish' },
  { code: 'DDS', name: 'Cashflow/DDS', description: 'Pul kirim/chiqim' },
  { code: 'DELIVERY', name: 'Delivery', description: 'Yetkazib berish buyurtmalari' },
  { code: 'ANALYTICS', name: 'Analytics', description: 'Real grafiklar va trendlar' },
  { code: 'HR', name: 'HR', description: 'Hodimlar, davomat, maosh' },
  { code: 'SERVICE_CENTER', name: 'Service Center', description: 'Remont va servis jarayoni' },
  { code: 'CALL_CENTER', name: 'Call Center', description: 'Lead, qo‘ng‘iroq va konversiya' },
  { code: 'MARKETING', name: 'Marketing', description: 'Reklama xarajatlari va ROI' },
  { code: 'API', name: 'API Access', description: 'Integratsiyalar uchun API' },
  { code: 'KPI', name: 'KPI', description: 'Xodim va bo‘limlar KPI' },
  { code: 'AI_DIRECTOR', name: 'AI Director', description: 'AI xulosa va maslahatlar' },
];

const DEFAULT_PLANS = [
  {
    code: 'FREE',
    name: 'Free',
    description: 'Lead generator: tizimni sinab ko‘rish uchun',
    monthlyPriceUZS: 0,
    modules: ['CRM', 'DEBTS', 'PAYMENTS'],
    clientLimit: 30,
    userLimit: 1,
    productLimit: 0,
    warehouseLimit: 0,
    sortOrder: 1,
  },
  {
    code: 'START',
    name: 'Start',
    description: 'Kichik magazinlar uchun asosiy CRM',
    monthlyPriceUZS: 99000,
    modules: ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS'],
    clientLimit: 300,
    userLimit: 2,
    productLimit: 0,
    warehouseLimit: 0,
    sortOrder: 2,
  },
  {
    code: 'SHOP',
    name: 'Shop',
    description: 'Do‘konlar uchun sklad, QR va mahsulot hisobi',
    monthlyPriceUZS: 299000,
    modules: ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS', 'INVENTORY', 'QR', 'STOCK_MOVEMENT'],
    clientLimit: 3000,
    userLimit: 5,
    productLimit: 5000,
    warehouseLimit: 3,
    sortOrder: 3,
  },
  {
    code: 'BUSINESS',
    name: 'Business',
    description: 'Digi World darajasidagi savdo bizneslari uchun',
    monthlyPriceUZS: 699000,
    modules: ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS', 'INVENTORY', 'QR', 'STOCK_MOVEMENT', 'POS', 'DDS', 'DELIVERY', 'ANALYTICS'],
    clientLimit: 10000,
    userLimit: 20,
    productLimit: 20000,
    warehouseLimit: 10,
    sortOrder: 4,
  },
  {
    code: 'CORPORATE',
    name: 'Corporate',
    description: 'Filialli katta kompaniyalar uchun to‘liq Business OS',
    monthlyPriceUZS: 1499000,
    modules: ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS', 'INVENTORY', 'QR', 'STOCK_MOVEMENT', 'POS', 'DDS', 'DELIVERY', 'ANALYTICS', 'HR', 'SERVICE_CENTER', 'CALL_CENTER', 'MARKETING', 'API', 'KPI'],
    clientLimit: null,
    userLimit: null,
    productLimit: null,
    warehouseLimit: null,
    sortOrder: 5,
  },
  {
    code: 'ENTERPRISE',
    name: 'Enterprise',
    description: 'Maxsus shartnoma: narx va limitlar Super Admin tomonidan belgilanadi',
    monthlyPriceUZS: 0,
    modules: ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS', 'INVENTORY', 'QR', 'STOCK_MOVEMENT', 'POS', 'DDS', 'DELIVERY', 'ANALYTICS', 'HR', 'SERVICE_CENTER', 'CALL_CENTER', 'MARKETING', 'API', 'KPI', 'AI_DIRECTOR'],
    clientLimit: null,
    userLimit: null,
    productLimit: null,
    warehouseLimit: null,
    sortOrder: 6,
  },
];

function toNumber(value: any, fallback = 0) {
  if (value === null || value === undefined || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function nullableInt(value: any) {
  if (value === null || value === undefined || value === '' || value === 'UNLIMITED') return null;
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : null;
}

function dateOrNull(value: any) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function normalizePhone(value: string) {
  const digits = String(value || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('998')) return `+${digits}`;
  return `+998${digits}`;
}

@Injectable()
export class SuperAdminService {
  constructor(private readonly prisma: PrismaService) {}

  private assertSuperAdmin(user: AuthUser) {
    if (!user || user.role !== 'SUPER_ADMIN') {
      throw new ForbiddenException('Faqat Super Admin uchun');
    }
  }

  modules(user: AuthUser) {
    this.assertSuperAdmin(user);
    return MODULES;
  }

  async overview(user: AuthUser) {
    this.assertSuperAdmin(user);
    const [companies, plans, active, trial, blocked, payments] = await Promise.all([
      this.prisma.company.count(),
      this.prisma.subscriptionPlan.count({ where: { isActive: true } }),
      this.prisma.company.count({ where: { status: 'ACTIVE' } }),
      this.prisma.company.count({ where: { status: 'TRIAL' } }),
      this.prisma.company.count({ where: { status: 'BLOCKED' } }),
      this.prisma.companyPlanPayment.aggregate({ _sum: { amountUZS: true } }),
    ]);

    return {
      companies,
      plans,
      active,
      trial,
      blocked,
      totalPaidUZS: payments._sum.amountUZS || 0,
    };
  }

  async seedDefaultPlans(user: AuthUser) {
    this.assertSuperAdmin(user);

    const result = [] as any[];
    for (const plan of DEFAULT_PLANS) {
      const saved = await this.prisma.subscriptionPlan.upsert({
        where: { code: plan.code },
        update: { ...plan, isSystem: true, isActive: true },
        create: { ...plan, isSystem: true, isActive: true },
      });
      result.push(saved);
    }

    return { ok: true, count: result.length, plans: result };
  }

  async plans(user: AuthUser) {
    this.assertSuperAdmin(user);
    const count = await this.prisma.subscriptionPlan.count();
    if (count === 0) await this.seedDefaultPlans(user);

    return this.prisma.subscriptionPlan.findMany({
      orderBy: [{ sortOrder: 'asc' }, { monthlyPriceUZS: 'asc' }],
    });
  }

  async createPlan(user: AuthUser, body: any) {
    this.assertSuperAdmin(user);
    const code = String(body.code || '').trim().toUpperCase().replace(/\s+/g, '_');
    const name = String(body.name || '').trim();
    if (!code || !name) throw new BadRequestException('Tarif kodi va nomi kerak');

    return this.prisma.subscriptionPlan.create({
      data: {
        code,
        name,
        description: body.description?.trim() || null,
        monthlyPriceUZS: toNumber(body.monthlyPriceUZS),
        modules: Array.isArray(body.modules) ? body.modules : [],
        clientLimit: nullableInt(body.clientLimit),
        userLimit: nullableInt(body.userLimit),
        productLimit: nullableInt(body.productLimit),
        warehouseLimit: nullableInt(body.warehouseLimit),
        isSystem: false,
        isActive: body.isActive !== false,
        sortOrder: toNumber(body.sortOrder, 99),
      },
    });
  }

  async updatePlan(user: AuthUser, id: string, body: any) {
    this.assertSuperAdmin(user);
    await this.ensurePlan(id);

    return this.prisma.subscriptionPlan.update({
      where: { id },
      data: {
        code: body.code !== undefined ? String(body.code).trim().toUpperCase().replace(/\s+/g, '_') : undefined,
        name: body.name !== undefined ? String(body.name).trim() : undefined,
        description: body.description !== undefined ? body.description?.trim() || null : undefined,
        monthlyPriceUZS: body.monthlyPriceUZS !== undefined ? toNumber(body.monthlyPriceUZS) : undefined,
        modules: body.modules !== undefined ? (Array.isArray(body.modules) ? body.modules : []) : undefined,
        clientLimit: body.clientLimit !== undefined ? nullableInt(body.clientLimit) : undefined,
        userLimit: body.userLimit !== undefined ? nullableInt(body.userLimit) : undefined,
        productLimit: body.productLimit !== undefined ? nullableInt(body.productLimit) : undefined,
        warehouseLimit: body.warehouseLimit !== undefined ? nullableInt(body.warehouseLimit) : undefined,
        isActive: body.isActive,
        sortOrder: body.sortOrder !== undefined ? toNumber(body.sortOrder, 99) : undefined,
      },
    });
  }

  async deletePlan(user: AuthUser, id: string) {
    this.assertSuperAdmin(user);
    const plan = await this.ensurePlan(id);
    const used = await this.prisma.company.count({ where: { planId: id } });
    if (used > 0 || plan.isSystem) {
      return this.prisma.subscriptionPlan.update({ where: { id }, data: { isActive: false } });
    }
    await this.prisma.subscriptionPlan.delete({ where: { id } });
    return { ok: true };
  }

  async companies(user: AuthUser) {
    this.assertSuperAdmin(user);
    return this.prisma.company.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        plan: true,
        _count: { select: { users: true, clients: true, products: true, warehouses: true } },
        planPayments: { orderBy: { paidAt: 'desc' }, take: 5 },
      },
    });
  }

  async createCompany(user: AuthUser, body: any) {
    this.assertSuperAdmin(user);
    const name = String(body.name || body.companyName || '').trim();
    const ownerName = String(body.ownerName || body.fullName || '').trim();
    const ownerPhone = normalizePhone(body.ownerPhone || body.phone || '');
    const password = String(body.ownerPassword || body.password || '').trim();

    if (!name || !ownerName || !ownerPhone || !password) {
      throw new BadRequestException('Kompaniya nomi, owner ismi, telefon va parol kerak');
    }

    const existing = await this.prisma.user.findUnique({ where: { phone: ownerPhone } });
    if (existing) throw new BadRequestException('Bu owner telefoni allaqachon mavjud');

    const plan = body.planId ? await this.ensurePlan(body.planId) : null;
    const modules = Array.isArray(body.enabledModules) ? body.enabledModules : plan?.modules || ['CRM', 'DEBTS', 'PAYMENTS', 'REPORTS'];
    const hash = await bcrypt.hash(password, 10);

    return this.prisma.company.create({
      data: {
        name,
        phone: body.phone || body.companyPhone || null,
        status: body.status || 'TRIAL',
        subscriptionPlan: plan?.code || body.subscriptionPlan || 'FREE',
        planId: plan?.id || null,
        enabledModules: modules,
        trialEndsAt: body.trialEndsAt ? dateOrNull(body.trialEndsAt) : null,
        monthlyPriceUZS: body.monthlyPriceUZS !== undefined ? toNumber(body.monthlyPriceUZS) : plan?.monthlyPriceUZS || 0,
        clientLimit: body.clientLimit !== undefined ? nullableInt(body.clientLimit) : plan?.clientLimit || null,
        userLimit: body.userLimit !== undefined ? nullableInt(body.userLimit) : plan?.userLimit || null,
        productLimit: body.productLimit !== undefined ? nullableInt(body.productLimit) : plan?.productLimit || null,
        warehouseLimit: body.warehouseLimit !== undefined ? nullableInt(body.warehouseLimit) : plan?.warehouseLimit || null,
        lastPaymentAt: dateOrNull(body.lastPaymentAt),
        nextPaymentAt: dateOrNull(body.nextPaymentAt),
        paymentDay: nullableInt(body.paymentDay),
        users: {
          create: {
            fullName: ownerName,
            phone: ownerPhone,
            password: hash,
            role: 'OWNER',
          },
        },
      },
      include: { users: true, plan: true },
    });
  }

  async updateCompany(user: AuthUser, id: string, body: any) {
    this.assertSuperAdmin(user);
    await this.ensureCompany(id);

    let plan: any = undefined;
    if (body.planId !== undefined) {
      plan = body.planId ? await this.ensurePlan(body.planId) : null;
    }

    const applyPlanDefaults = Boolean(body.applyPlanDefaults);

    return this.prisma.company.update({
      where: { id },
      data: {
        name: body.name !== undefined ? String(body.name).trim() : undefined,
        phone: body.phone !== undefined ? body.phone || null : undefined,
        status: body.status,
        planId: body.planId !== undefined ? plan?.id || null : undefined,
        subscriptionPlan: plan ? plan.code : body.subscriptionPlan,
        enabledModules: body.enabledModules !== undefined ? (Array.isArray(body.enabledModules) ? body.enabledModules : []) : applyPlanDefaults && plan ? plan.modules : undefined,
        monthlyPriceUZS: body.monthlyPriceUZS !== undefined ? toNumber(body.monthlyPriceUZS) : applyPlanDefaults && plan ? plan.monthlyPriceUZS : undefined,
        clientLimit: body.clientLimit !== undefined ? nullableInt(body.clientLimit) : applyPlanDefaults && plan ? plan.clientLimit : undefined,
        userLimit: body.userLimit !== undefined ? nullableInt(body.userLimit) : applyPlanDefaults && plan ? plan.userLimit : undefined,
        productLimit: body.productLimit !== undefined ? nullableInt(body.productLimit) : applyPlanDefaults && plan ? plan.productLimit : undefined,
        warehouseLimit: body.warehouseLimit !== undefined ? nullableInt(body.warehouseLimit) : applyPlanDefaults && plan ? plan.warehouseLimit : undefined,
        lastPaymentAt: body.lastPaymentAt !== undefined ? dateOrNull(body.lastPaymentAt) : undefined,
        nextPaymentAt: body.nextPaymentAt !== undefined ? dateOrNull(body.nextPaymentAt) : undefined,
        paymentDay: body.paymentDay !== undefined ? nullableInt(body.paymentDay) : undefined,
        paymentComment: body.paymentComment !== undefined ? body.paymentComment || null : undefined,
      },
      include: { plan: true, _count: { select: { users: true, clients: true, products: true, warehouses: true } } },
    });
  }

  async addCompanyPayment(user: AuthUser, companyId: string, body: any) {
    this.assertSuperAdmin(user);
    const company = await this.ensureCompany(companyId);
    const paidAt = dateOrNull(body.paidAt) || new Date();
    const periodTo = dateOrNull(body.periodTo);

    const payment = await this.prisma.companyPlanPayment.create({
      data: {
        companyId,
        amountUZS: toNumber(body.amountUZS, company.monthlyPriceUZS || 0),
        paidAt,
        periodFrom: dateOrNull(body.periodFrom),
        periodTo,
        method: body.method?.trim() || null,
        comment: body.comment?.trim() || null,
      },
    });

    await this.prisma.company.update({
      where: { id: companyId },
      data: {
        status: 'ACTIVE',
        lastPaymentAt: paidAt,
        nextPaymentAt: periodTo || company.nextPaymentAt,
      },
    });

    return payment;
  }

  private async ensurePlan(id: string) {
    const plan = await this.prisma.subscriptionPlan.findUnique({ where: { id } });
    if (!plan) throw new NotFoundException('Tarif topilmadi');
    return plan;
  }

  private async ensureCompany(id: string) {
    const company = await this.prisma.company.findUnique({ where: { id } });
    if (!company) throw new NotFoundException('Kompaniya topilmadi');
    return company;
  }
}
