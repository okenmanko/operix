import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { CompaniesModule } from './companies/companies.module';
import { ClientsModule } from './clients/clients.module';
import { DebtsModule } from './debts/debts.module';
import { PaymentsModule } from './payments/payments.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AuthModule } from './auth/auth.module';
import { AuthzModule } from './authz/authz.module';
import { UsersModule } from './users/users.module';
import { DeliveryModule } from './delivery/delivery.module';
import { InventoryModule } from './inventory/inventory.module';
import { CashflowModule } from './cashflow/cashflow.module';
import { PosModule } from './pos/pos.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { SuperAdminModule } from './super-admin/super-admin.module';
import { QrModule } from './qr/qr.module';
import { SalesModule } from './sales/sales.module';
import { BillingModule } from './billing/billing.module';

@Module({
  imports: [
    PrismaModule,
    AuthModule,
    AuthzModule,
    SuperAdminModule,
    CompaniesModule,
    ClientsModule,
    DebtsModule,
    PaymentsModule,
    DashboardModule,
    UsersModule,
    DeliveryModule,
    InventoryModule,
    CashflowModule,
    PosModule,
    SalesModule,
    AnalyticsModule,
    QrModule,
    BillingModule,
  ],
})
export class AppModule {}
