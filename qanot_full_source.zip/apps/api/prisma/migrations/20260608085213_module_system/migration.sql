-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "trialEndsAt" TIMESTAMP(3),
ALTER COLUMN "enabledModules" SET DEFAULT ARRAY['CRM', 'HR', 'DELIVERY']::TEXT[],
ALTER COLUMN "status" SET DEFAULT 'TRIAL';
